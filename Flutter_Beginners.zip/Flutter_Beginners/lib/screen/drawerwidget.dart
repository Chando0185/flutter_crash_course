import 'package:flutter/material.dart';

class DrawerWidget extends StatefulWidget {
  const DrawerWidget({Key? key}) : super(key: key);

  @override
  _DrawerWidgetState createState() => _DrawerWidgetState();
}

class _DrawerWidgetState extends State<DrawerWidget> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: ListView(
          children: [
            UserAccountsDrawerHeader(
                otherAccountsPictures: [
                  CircleAvatar(
                    child: ClipOval(
                      child: Image.asset(
                        'assets/image01.jpg',
                        width: 240,
                        height: 240,
                        fit: BoxFit.cover,
                      ),
                    ),
                    radius: 40,
                  ),
                ],
                currentAccountPicture: CircleAvatar(
                  child: ClipOval(
                    child: Image.asset(
                      'assets/chando.jpg',
                      width: 240,
                      height: 240,
                      fit: BoxFit.cover,
                    ),
                  ),
                  radius: 40,
                ),
                accountName: Text(
                  "Chando Dhar",
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
                accountEmail: Text("name@gmail.com")),
            // DrawerHeader(
            //     decoration: BoxDecoration(color: Colors.redAccent),
            //     child: Column(
            //       children: [
            //         CircleAvatar(
            //           // backgroundImage: NetworkImage(img3),
            //           child: ClipOval(
            //             child: Image.asset(
            //               'assets/chando.jpg',
            //               width: 240,
            //               height: 240,
            //               fit: BoxFit.cover,
            //             ),
            //           ),
            //           radius: 40,
            //         ),
            //         SizedBox(
            //           height: 5,
            //         ),
            //         Text(
            //           "Chando Dhar",
            //           style: TextStyle(
            //               color: Colors.white,
            //               fontWeight: FontWeight.bold,
            //               fontSize: 20),
            //         ),
            //         SizedBox(
            //           height: 5,
            //         ),
            //         Text("Flutter Developer")
            //       ],
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  ListTile(
                    title: Text("Home"),
                    leading: Icon(Icons.home_outlined),
                    onTap: () {},
                  ),
                  ListTile(
                    title: Text("Favourite"),
                    leading: Icon(Icons.favorite_border),
                    onTap: () {},
                  ),
                  ListTile(
                    title: Text("Workflow"),
                    leading: Icon(Icons.workspaces_outline),
                    onTap: () {},
                  ),
                  ListTile(
                    title: Text("Update"),
                    leading: Icon(Icons.update),
                    onTap: () {},
                  ),
                  Divider(
                    thickness: 2,
                  ),
                  ListTile(
                    title: Text("Plugins"),
                    leading: Icon(Icons.account_tree_outlined),
                    onTap: () {},
                  ),
                  ListTile(
                    title: Text("Notification"),
                    leading: Icon(Icons.notifications_outlined),
                    onTap: () {},
                  )
                ],
              ),
            )
          ],
        ),
      ),
      appBar: AppBar(
        backgroundColor: Colors.red,
        title: Text("Drawer Widget"),
        centerTitle: true,
      ),
    );
  }
}
