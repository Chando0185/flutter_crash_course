import 'package:flutter/material.dart';

class NavigatorPage extends StatefulWidget {
  const NavigatorPage({Key? key}) : super(key: key);

  @override
  _NavigatorPageState createState() => _NavigatorPageState();
}

class _NavigatorPageState extends State<NavigatorPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Page 01"),
        centerTitle: true,
      ),
      body: Center(
        child: ElevatedButton(
            style: ElevatedButton.styleFrom(
                minimumSize: Size(280, 70),
                textStyle: TextStyle(fontSize: 24),
                primary: Colors.orange,
                onPrimary: Colors.black),
            onPressed: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => Page02(data: "KNOWLEDGE DOCTOR")));
            },
            child: Text("Page 01")),
      ),
    );
  }
}

class Page02 extends StatefulWidget {
  var data;
  Page02({this.data, Key? key}) : super(key: key);

  @override
  _Page02State createState() => _Page02State();
}

class _Page02State extends State<Page02> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Page 02"),
        centerTitle: true,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(
            width: double.infinity,
          ),
          ElevatedButton(
              style: ElevatedButton.styleFrom(
                  minimumSize: Size(280, 70),
                  textStyle: TextStyle(fontSize: 24),
                  primary: Colors.orange,
                  onPrimary: Colors.black),
              onPressed: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (context) => Page03()));
              },
              child: Text("Page 02")),
          SizedBox(
            height: 12,
          ),
          Text(widget.data),
        ],
      ),
    );
  }
}

class Page03 extends StatefulWidget {
  const Page03({Key? key}) : super(key: key);

  @override
  _Page03State createState() => _Page03State();
}

class _Page03State extends State<Page03> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Page 03"),
        centerTitle: true,
      ),
      body: Center(
        child: ElevatedButton(
            style: ElevatedButton.styleFrom(
                minimumSize: Size(280, 70),
                textStyle: TextStyle(fontSize: 24),
                primary: Colors.orange,
                onPrimary: Colors.black),
            onPressed: () {
              Navigator.popUntil(context, ModalRoute.withName("/"));
            },
            child: Text("Page 03")),
      ),
    );
  }
}
