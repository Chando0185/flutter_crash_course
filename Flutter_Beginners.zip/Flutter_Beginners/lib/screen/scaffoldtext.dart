import 'package:flutter/material.dart';

class ScaffoldandTextWidget extends StatelessWidget {
  const ScaffoldandTextWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // backgroundColor: Colors.redAccent,
      appBar: AppBar(
        backgroundColor: Colors.redAccent,
        title: Text("Appbar"),
        centerTitle: true,
      ),
      body: Center(
          child: Text(
              "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever",
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.w900,
                  color: Colors.black,
                  shadows: [
                    BoxShadow(
                        blurRadius: 10,
                        color: Colors.white,
                        offset: Offset(0, 1))
                  ],
                  // foreground: Paint()..style = PaintingStyle.stroke,
                  backgroundColor: Colors.green))),
      drawer: Drawer(),
      bottomNavigationBar: BottomNavigationBar(items: [
        BottomNavigationBarItem(
            backgroundColor: Colors.red, icon: Icon(Icons.home), label: "Home"),
        BottomNavigationBarItem(icon: Icon(Icons.settings), label: "Setting")
      ]),
    );
  }
}
