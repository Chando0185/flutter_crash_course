import 'package:flutter/material.dart';

class StackWidget extends StatefulWidget {
  const StackWidget({Key? key}) : super(key: key);

  @override
  _StackWidgetState createState() => _StackWidgetState();
}

class _StackWidgetState extends State<StackWidget> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Stack Widget"),
        centerTitle: true,
      ),
      body: Container(
        alignment: Alignment.center,
        child: Stack(
          // overflow: Overflow.visible,
          clipBehavior: Clip.none,
          alignment: Alignment.centerLeft,
          // fit: StackFit.expand,
          // textDirection: TextDirection.rtl,
          children: [
            Container(
              width: 250,
              height: 250,
              color: Colors.redAccent,
            ),
            Container(
              width: 200,
              height: 200,
              color: Colors.greenAccent,
            ),
            Positioned(
              bottom: -20,
              left: -20,
              child: Container(
                width: 150,
                height: 150,
                color: Colors.blueAccent,
              ),
            ),
            // Text("Hello Chando"),
          ],
        ),
      ),
    );
  }
}
