import 'package:flutter/material.dart';

class ListViewWidget extends StatelessWidget {
  const ListViewWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final lst = List.generate(100, (index) => "$index");
    final lst1 = [
      "Bangladesh",
      "India",
      "USA",
      "Nepal",
      "Pakistan",
      "Sri-Lanka"
    ];
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red,
        title: Text("Listview Widget"),
        centerTitle: true,
      ),
      // body: ListView(
      //   children: [
      //     ListTile(
      //       title: Text("Chando Dhar"),
      //       subtitle: Text("Flutter Developer"),
      //       trailing: Icon(
      //         Icons.star,
      //         color: Colors.orange,
      //       ),
      //       leading: CircleAvatar(
      //         backgroundColor: Colors.brown.shade800,
      //         child: Text("CD"),
      //       ),
      //     ),
      //     ListTile(
      //       title: Text("Chando Dhar"),
      //       subtitle: Text("Flutter Developer"),
      //       trailing: Icon(
      //         Icons.star,
      //         color: Colors.orange,
      //       ),
      //       leading: CircleAvatar(
      //         backgroundColor: Colors.brown.shade800,
      //         child: Text("CD"),
      //       ),
      //     ),
      //   ],
      // ),
      body: ListView.separated(
          separatorBuilder: (context, index) => Divider(color: Colors.black),
          itemCount: lst1.length,
          itemBuilder: (context, index) {
            return ListTile(
              onTap: () {
                print(lst1[index]);
              },
              title: Text(lst1[index]),
              subtitle: Text("Country Name"),
              trailing: Icon(
                Icons.star,
                color: Colors.orange,
              ),
              leading: CircleAvatar(
                backgroundColor: Colors.brown.shade800,
                child: Text(lst1[index][0]),
              ),
            );
          }),
    );
  }
}
