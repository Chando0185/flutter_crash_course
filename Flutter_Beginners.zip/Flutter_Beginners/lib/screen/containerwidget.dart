import 'package:flutter/material.dart';

class ContainerWidget extends StatelessWidget {
  const ContainerWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red,
        title: Text("Container Widget"),
        centerTitle: true,
      ),
      body: InkWell(
        onTap: () {
          print("Pressed");
        },
        child: Center(
          child: Container(
            // margin: EdgeInsets.fromLTRB(10, 20, 40, 10),
            padding: EdgeInsets.all(50),
            child: Text("KNOWLEDGE"),
            // alignment: Alignment.center,
            // width: 200,
            // height: 50,
            // constraints: BoxConstraints(
            //     minWidth: 20, maxWidth: 100, maxHeight: 100, minHeight: 20),
            decoration: BoxDecoration(
                color: Colors.green,
                // borderRadius: BorderRadius.circular(20),
                // shape: BoxShape.circle,
                border: Border.all(color: Colors.red, width: 5)),
          ),
        ),
      ),
    );
  }
}
