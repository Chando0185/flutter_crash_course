import 'package:flutter/material.dart';

class ImageWidget extends StatelessWidget {
  const ImageWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final img1 = "https://i.postimg.cc/HkrJJsq4/for-dr-4x.webp";

    final img2 =
        "https://i.postimg.cc/WzxBX844/cb586aa6b06f2cfa372d83aff0a1795e.webp";
    final img3 = "https://i.postimg.cc/B6rJYHNM/image01.jpg";
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.red,
          title: Text("Image Widget"),
          centerTitle: true,
        ),
        body: ListView(
          children: [
            Image.network(img1,
                width: 240,
                height: 240,
                fit: BoxFit.cover,
                loadingBuilder: (context, child, loadingProgress) =>
                    loadingProgress == null
                        ? child
                        : Container(
                            width: 240,
                            height: 240,
                            child: Center(
                              child: CircularProgressIndicator(),
                            ),
                          )),
            CircleAvatar(
              backgroundImage: NetworkImage(img3),
              radius: 120,
            ),
            CircleAvatar(
              // backgroundImage: NetworkImage(img3),
              child: ClipOval(
                child: Image.network(
                  img3,
                  width: 240,
                  height: 240,
                  fit: BoxFit.cover,
                ),
              ),
              radius: 120,
            ),
            Image.asset(
              'assets/image02.png',
              width: 240,
              height: 240,
              fit: BoxFit.cover,
            ),
            CircleAvatar(
              // backgroundImage: NetworkImage(img3),
              child: ClipOval(
                child: Image.asset(
                  'assets/image02.png',
                  width: 240,
                  height: 240,
                  fit: BoxFit.cover,
                ),
              ),
              radius: 120,
            ),
            CircleAvatar(
              backgroundImage: AssetImage('assets/image02.png'),
              radius: 120,
            ),
          ],
        ));
  }
}
