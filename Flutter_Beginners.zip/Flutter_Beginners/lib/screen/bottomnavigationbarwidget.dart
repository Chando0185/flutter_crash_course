import 'package:flutter/material.dart';

class BottomNavigationBarWidget extends StatefulWidget {
  const BottomNavigationBarWidget({Key? key}) : super(key: key);

  @override
  _BottomNavigationBarWidgetState createState() =>
      _BottomNavigationBarWidgetState();
}

class _BottomNavigationBarWidgetState extends State<BottomNavigationBarWidget> {
  final pages = [Home(), Favourite(), Contacts()];
  var currentindex = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
          selectedItemColor: Colors.white,
          backgroundColor: Colors.greenAccent,
          currentIndex: currentindex,
          onTap: (index) {
            setState(() {
              currentindex = index;
            });
          },
          items: [
            BottomNavigationBarItem(
                icon: Icon(Icons.home_outlined), title: SizedBox.shrink()),
            BottomNavigationBarItem(
                icon: Icon(Icons.favorite_outline_outlined),
                title: SizedBox.shrink()),
            BottomNavigationBarItem(
                icon: Icon(Icons.contacts_outlined), title: SizedBox.shrink())
          ]),
      appBar: AppBar(
        backgroundColor: Colors.red,
      ),
      body: pages[currentindex],
    );
  }
}

class Home extends StatelessWidget {
  const Home({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
        child: Text(
      "Home",
      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24),
    ));
  }
}

class Favourite extends StatelessWidget {
  const Favourite({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
        child: Text(
      "Favourite",
      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24),
    ));
  }
}

class Contacts extends StatelessWidget {
  const Contacts({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text("Contacts",
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24)),
    );
  }
}
