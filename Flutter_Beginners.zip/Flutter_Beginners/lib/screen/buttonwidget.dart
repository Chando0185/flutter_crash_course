import 'package:flutter/material.dart';

class ButtonWidget extends StatelessWidget {
  const ButtonWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.red,
          title: Text("Button Widget"),
          centerTitle: true,
        ),
        body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: ListView(
            children: [
              ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      minimumSize: Size(280, 70),
                      textStyle: TextStyle(fontSize: 24),
                      primary: Colors.orange,
                      onPrimary: Colors.black),
                  onPressed: () {
                    print("ElevatedButton Button Pressed");
                  },
                  child: Text("ElevatedButton")),
              SizedBox(
                height: 15,
              ),
              OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    minimumSize: Size(280, 70),
                    textStyle: TextStyle(fontSize: 24),
                    primary: Colors.greenAccent,
                    side: BorderSide(width: 3, color: Colors.blueAccent),
                  ),
                  onPressed: () {
                    print("OutlinedButton Button Pressed");
                  },
                  child: Text("OutlinedButton")),
              SizedBox(
                height: 15,
              ),
              IconButton(
                  iconSize: 80,
                  onPressed: () {},
                  icon: Icon(Icons.settings, color: Colors.blue))
            ],
          ),
        ));
  }
}
