import 'package:flutter/material.dart';
import 'package:flutter_for_beginners/screen/bottomnavigationbarwidget.dart';
import 'package:flutter_for_beginners/screen/buttonwidget.dart';
import 'package:flutter_for_beginners/screen/cardwidget.dart';
import 'package:flutter_for_beginners/screen/containerwidget.dart';
import 'package:flutter_for_beginners/screen/drawerwidget.dart';
import 'package:flutter_for_beginners/screen/homepage.dart';
import 'package:flutter_for_beginners/screen/imagewidget.dart';
import 'package:flutter_for_beginners/screen/listviewwidget.dart';
import 'package:flutter_for_beginners/screen/navigatorpage.dart';
import 'package:flutter_for_beginners/screen/pageviewwidget.dart';
import 'package:flutter_for_beginners/screen/rowcolumn.dart';
import 'package:flutter_for_beginners/screen/scaffoldtext.dart';
import 'package:flutter_for_beginners/screen/stackwidget.dart';
import 'package:flutter_for_beginners/screen/tabbarwidget.dart';
import 'package:flutter_for_beginners/screen/textfieldwidget.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.red,
      ),
      home: StackWidget(),
    );
  }
}
