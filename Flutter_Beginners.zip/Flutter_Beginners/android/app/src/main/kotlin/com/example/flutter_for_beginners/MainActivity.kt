package com.example.flutter_for_beginners

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
